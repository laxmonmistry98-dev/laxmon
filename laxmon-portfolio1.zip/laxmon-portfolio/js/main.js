/* =========================================================
   LAXMON MISTRY — Portfolio  |  main.js (vanilla, no deps)
   ========================================================= */
(() => {
  'use strict';

  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const lerp = (a, b, t) => a + (b - a) * t;

  document.documentElement.classList.remove('no-js');

  /* ---------- Header: solid on scroll + back-to-top ---------- */
  const header = $('.site-header');
  const toTop = $('.to-top');
  const onScroll = () => {
    const y = window.scrollY;
    header && header.classList.toggle('is-scrolled', y > 24);
    toTop && toTop.classList.toggle('show', y > 700);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  toTop && toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }));

  /* ---------- Mobile menu ---------- */
  const toggle = $('.nav-toggle');
  const menu = $('#mobile-menu');
  const setMenu = (open) => {
    document.body.classList.toggle('nav-open', open);
    if (toggle) {
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    }
    if (menu) menu.setAttribute('aria-hidden', String(!open));
  };
  toggle && toggle.addEventListener('click', () => setMenu(!document.body.classList.contains('nav-open')));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setMenu(false); });
  window.addEventListener('resize', () => { if (window.innerWidth > 1024) setMenu(false); });

  /* ---------- Page transition ---------- */
  const wipeLabel = $('.page-wipe span');
  const labels = { 'index.html': 'Home', 'about.html': 'About', 'services.html': 'Services', 'projects.html': 'Projects', 'contact.html': 'Contact' };
  if (!reduceMotion && sessionStorageSafe('get', 'lm-transition') === '1') {
    document.body.classList.add('is-entering');
    sessionStorageSafe('remove', 'lm-transition');
    setTimeout(() => document.body.classList.remove('is-entering'), 1000);
  }
  function sessionStorageSafe(op, key, val) {
    try {
      if (op === 'get') return sessionStorage.getItem(key);
      if (op === 'set') return sessionStorage.setItem(key, val);
      if (op === 'remove') return sessionStorage.removeItem(key);
    } catch (e) { return null; }
  }
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) return;
    if (a.target === '_blank' || a.hasAttribute('download')) return;
    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin || url.pathname === location.pathname && url.hash) return;
    if (!/\.html$|\/$/.test(url.pathname) && url.pathname !== '/') return;
    if (url.pathname === location.pathname && !url.hash && !url.search) return;
    if (reduceMotion) return;
    e.preventDefault();
    setMenu(false);
    const file = url.pathname.split('/').pop() || 'index.html';
    if (wipeLabel) wipeLabel.textContent = labels[file] || 'LAXMON';
    document.body.classList.add('is-leaving');
    sessionStorageSafe('set', 'lm-transition', '1');
    setTimeout(() => { location.href = a.href; }, 520);
  });
  window.addEventListener('pageshow', (e) => { if (e.persisted) document.body.classList.remove('is-leaving'); });

  /* ---------- Scroll reveal (IntersectionObserver) ---------- */
  const revealEls = $$('.reveal, .skill-bar, .tech-card, .process');
  if ('IntersectionObserver' in window && !reduceMotion) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target); }
      });
    }, { threshold: 0.14, rootMargin: '0px 0px -6% 0px' });
    revealEls.forEach((el) => io.observe(el));
  } else {
    revealEls.forEach((el) => el.classList.add('is-visible'));
  }

  /* ---------- Count-up numbers ---------- */
  const counters = $$('[data-count]');
  const runCount = (el) => {
    const target = parseFloat(el.dataset.count);
    const suffix = el.dataset.suffix || '';
    if (reduceMotion) { el.textContent = target + suffix; return; }
    const dur = 1800;
    const t0 = performance.now();
    const tick = (t) => {
      const p = Math.min((t - t0) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 4);
      el.textContent = Math.round(target * eased) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };
  if ('IntersectionObserver' in window) {
    const co = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) { runCount(en.target); co.unobserve(en.target); } });
    }, { threshold: 0.6 });
    counters.forEach((c) => co.observe(c));
  } else counters.forEach(runCount);

  /* ---------- Card tilt + spotlight ---------- */
  if (finePointer && !reduceMotion) {
    $$('.tilt').forEach((card) => {
      const max = parseFloat(card.dataset.tilt || 7);
      card.addEventListener('pointermove', (e) => {
        const r = card.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width;
        const py = (e.clientY - r.top) / r.height;
        card.style.transform = `perspective(900px) rotateX(${(0.5 - py) * max}deg) rotateY(${(px - 0.5) * max}deg) translateZ(0)`;
        card.style.setProperty('--mx', px * 100 + '%');
        card.style.setProperty('--my', py * 100 + '%');
      });
      card.addEventListener('pointerleave', () => { card.style.transform = ''; });
    });
    $$('.svc-detail').forEach((c) => c.addEventListener('pointermove', (e) => {
      const r = c.getBoundingClientRect();
      c.style.setProperty('--mx', ((e.clientX - r.left) / r.width) * 100 + '%');
      c.style.setProperty('--my', ((e.clientY - r.top) / r.height) * 100 + '%');
    }));
  }

  /* ---------- Hero parallax for floating cards ---------- */
  const stage = $('.profile-stage');
  if (stage && finePointer && !reduceMotion) {
    const layers = $$('[data-depth]', stage);
    stage.addEventListener('pointermove', (e) => {
      const r = stage.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      layers.forEach((l) => {
        const d = parseFloat(l.dataset.depth);
        l.style.translate = `${x * d}px ${y * d}px`;
      });
    });
    stage.addEventListener('pointerleave', () => layers.forEach((l) => { l.style.translate = ''; }));
  }

  /* ---------- Terminal typing effect ---------- */
  const term = $('#terminal');
  if (term) {
    const lines = [
      ['$ ', 'wp scaffold _s laxmon-theme', false],
      ['✔ ', 'Theme scaffolded', true],
      ['$ ', 'composer require acme/api-client', false],
      ['✔ ', 'API integration ready', true],
      ['✔ ', 'Lighthouse score: 98', true],
    ];
    const out = $('.term-out', term);
    if (reduceMotion) {
      out.innerHTML = lines.map(([p, t, ok]) => `<div>${ok ? '<span class="ok">' + p + '</span>' : p}${t}</div>`).join('') + '<span class="caret"></span>';
    } else {
      let li = 0;
      const typeLine = () => {
        if (li >= lines.length) { out.insertAdjacentHTML('beforeend', '<span class="caret"></span>'); return; }
        const [p, t, ok] = lines[li];
        const row = document.createElement('div');
        row.innerHTML = ok ? `<span class="ok">${p}</span>` : p;
        const txt = document.createElement('span');
        row.appendChild(txt);
        out.appendChild(row);
        let ci = 0;
        const step = () => {
          txt.textContent = t.slice(0, ++ci);
          if (ci < t.length) setTimeout(step, ok ? 14 : 38);
          else { li++; setTimeout(typeLine, ok ? 260 : 420); }
        };
        step();
      };
      setTimeout(typeLine, 1200);
    }
  }

  /* ---------- Custom cursor ---------- */
  if (finePointer) {
    const dot = $('.cursor-dot');
    const ring = $('.cursor-ring');
    if (dot && ring && !reduceMotion) {
      document.body.classList.add('has-cursor');
      let mx = innerWidth / 2, my = innerHeight / 2, rx = mx, ry = my;
      window.addEventListener('pointermove', (e) => { mx = e.clientX; my = e.clientY; dot.style.transform = `translate(${mx}px, ${my}px)`; }, { passive: true });
      const loop = () => {
        rx = lerp(rx, mx, 0.16); ry = lerp(ry, my, 0.16);
        ring.style.transform = `translate(${rx}px, ${ry}px)`;
        requestAnimationFrame(loop);
      };
      requestAnimationFrame(loop);
      const setState = (t) => {
        const isBtn = t.closest('.btn, button, .filter-btn, [type="submit"]');
        const isLink = t.closest('a, summary, .step, .tech-card, .project-card');
        ring.classList.toggle('is-button', !!isBtn);
        ring.classList.toggle('is-link', !isBtn && !!isLink);
      };
      document.addEventListener('pointerover', (e) => setState(e.target));
      document.addEventListener('pointerdown', () => ring.classList.add('is-down'));
      document.addEventListener('pointerup', () => ring.classList.remove('is-down'));
      document.addEventListener('mouseleave', () => { dot.style.opacity = 0; ring.style.opacity = 0; });
      document.addEventListener('mouseenter', () => { dot.style.opacity = ''; ring.style.opacity = ''; });
    }
  }

  /* ---------- Particle background ---------- */
  const canvas = $('#particles');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let w, h, dpr, parts = [], running = true;
    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.width = innerWidth * dpr; h = canvas.height = innerHeight * dpr;
      const n = Math.min(70, Math.round(innerWidth / 22));
      parts = Array.from({ length: n }, () => ({
        x: Math.random() * w, y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.25 * dpr, vy: (Math.random() - 0.5) * 0.25 * dpr,
        r: (Math.random() * 1.4 + 0.5) * dpr, c: Math.random() > 0.5 ? '139,92,246' : '34,211,238'
      }));
      draw(true);
    };
    const draw = (still) => {
      ctx.clearRect(0, 0, w, h);
      const maxD = 130 * dpr;
      for (let i = 0; i < parts.length; i++) {
        const p = parts[i];
        if (!still) { p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > w) p.vx *= -1; if (p.y < 0 || p.y > h) p.vy *= -1; }
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.283); ctx.fillStyle = `rgba(${p.c},.75)`; ctx.fill();
        for (let j = i + 1; j < parts.length; j++) {
          const q = parts[j]; const dx = p.x - q.x, dy = p.y - q.y; const d = Math.hypot(dx, dy);
          if (d < maxD) { ctx.strokeStyle = `rgba(110,130,255,${(1 - d / maxD) * 0.16})`; ctx.lineWidth = dpr * 0.6; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke(); }
        }
      }
    };
    const frame = () => { if (running) draw(false); requestAnimationFrame(frame); };
    let rt; window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(resize, 200); });
    document.addEventListener('visibilitychange', () => { running = !document.hidden; });
    resize();
    if (!reduceMotion) requestAnimationFrame(frame);
  }

  /* ---------- Process steps hover highlight ---------- */
  $$('.step').forEach((s) => {
    s.addEventListener('mouseenter', () => s.classList.add('is-hot'));
    s.addEventListener('mouseleave', () => s.classList.remove('is-hot'));
  });

  /* ---------- Project filter ---------- */
  const filterBar = $('.filter-bar');
  if (filterBar) {
    const cards = $$('.project-card[data-cat]');
    const empty = $('.empty-state');
    $$('.filter-btn', filterBar).forEach((btn) => {
      const f = btn.dataset.filter;
      const n = f === 'all' ? cards.length : cards.filter((c) => c.dataset.cat.split(' ').includes(f)).length;
      const badge = btn.querySelector('.count'); if (badge) badge.textContent = n;
    });
    filterBar.addEventListener('click', (e) => {
      const btn = e.target.closest('.filter-btn');
      if (!btn) return;
      $$('.filter-btn', filterBar).forEach((b) => { b.classList.remove('is-active'); b.setAttribute('aria-pressed', 'false'); });
      btn.classList.add('is-active'); btn.setAttribute('aria-pressed', 'true');
      const f = btn.dataset.filter;
      cards.forEach((c) => c.classList.add('is-fading'));
      setTimeout(() => {
        let shown = 0;
        cards.forEach((c) => {
          const match = f === 'all' || c.dataset.cat.split(' ').includes(f);
          c.classList.toggle('is-hidden', !match);
          if (match) { shown++; c.classList.add('is-visible'); }
        });
        if (empty) empty.style.display = shown ? 'none' : 'block';
        requestAnimationFrame(() => requestAnimationFrame(() => cards.forEach((c) => c.classList.remove('is-fading'))));
      }, reduceMotion ? 0 : 280);
      if (location.hash !== '#' + f) history.replaceState(null, '', f === 'all' ? location.pathname : '#' + f);
    });
    const hash = location.hash.slice(1);
    const initial = hash && $(`.filter-btn[data-filter="${hash}"]`, filterBar);
    if (initial) initial.click();
  }

  /* ---------- Project details modal ---------- */
  const modal = $('#project-modal');
  if (modal && typeof modal.showModal === 'function') {
    const body = $('.modal-body', modal);
    document.addEventListener('click', (e) => {
      const trg = e.target.closest('[data-details]');
      if (trg) {
        const tpl = document.getElementById(trg.dataset.details);
        if (!tpl) return;
        body.innerHTML = tpl.innerHTML;
        modal.showModal();
        document.body.style.overflow = 'hidden';
      }
      if (e.target.closest('.modal-close') || e.target === modal) modal.close();
    });
    modal.addEventListener('close', () => { document.body.style.overflow = ''; });
  } else if (modal) {
    document.addEventListener('click', (e) => { const t = e.target.closest('[data-details]'); if (t) { e.preventDefault(); location.href = 'contact.html'; } });
  }

  /* ---------- Contact form ---------- */
  const form = $('#contact-form');
  if (form) {
    const endpoint = form.dataset.endpoint;
    const tokenUrl = form.dataset.token;
    const alertOk = $('.alert.success', form);
    const alertErr = $('.alert.error', form);
    const submitBtn = $('button[type="submit"]', form);
    let csrf = '', mathQ = '', fieldLoadedAt = Date.now();

    // Pre-select service from ?service=
    const svc = new URLSearchParams(location.search).get('service');
    if (svc) { const sel = form.elements.service; if (sel) { [...sel.options].forEach((o) => { if (o.value.toLowerCase() === svc.toLowerCase()) sel.value = o.value; }); } }

    // Human-check question + CSRF token from PHP (graceful fallback when PHP is unavailable)
    const mathLabel = $('#human-label');
    const a = 2 + Math.floor(Math.random() * 7), b = 1 + Math.floor(Math.random() * 7);
    let localAnswer = a + b;
    mathQ = `${a} + ${b} = ?`;
    if (mathLabel) mathLabel.textContent = 'Human check: ' + mathQ;
    const loadToken = () => fetch(tokenUrl, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((j) => { if (j && j.token) { csrf = j.token; if (mathLabel && j.question) { mathLabel.textContent = 'Human check: ' + j.question; localAnswer = null; } } })
      .catch(() => { /* static hosting: handled on submit */ });
    loadToken();

    const rules = {
      name: (v) => (v.trim().length >= 2 ? '' : 'Please enter your full name (at least 2 characters).'),
      email: (v) => (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? '' : 'Enter a valid email address, like name@company.com.'),
      phone: (v) => (!v.trim() || /^[+()\d\s.-]{7,20}$/.test(v.trim()) ? '' : 'Use 7–20 digits. You can include +, spaces or dashes.'),
      service: (v) => (v ? '' : 'Choose the service you need.'),
      budget: (v) => (v ? '' : 'Pick a budget range so I can scope the work.'),
      message: (v) => (v.trim().length >= 20 ? '' : 'Tell me a little more (at least 20 characters).'),
      human: (v) => (v.trim() === '' ? 'Answer the quick human check.' : (localAnswer !== null && Number(v) !== localAnswer ? 'That answer is not right. Try again.' : ''))
    };
    const setErr = (field, msg) => {
      const wrap = field.closest('.field'); if (!wrap) return;
      wrap.classList.toggle('has-error', !!msg);
      wrap.classList.toggle('is-valid', !msg && field.value.trim() !== '');
      const err = $('.err', wrap); if (err) err.textContent = msg;
      field.setAttribute('aria-invalid', msg ? 'true' : 'false');
    };
    const validateField = (field) => { const r = rules[field.name]; if (!r) return true; const m = r(field.value); setErr(field, m); return !m; };
    $$('input, select, textarea', form).forEach((f) => {
      if (!rules[f.name]) return;
      f.addEventListener('blur', () => validateField(f));
      f.addEventListener('input', () => { if (f.closest('.field').classList.contains('has-error')) validateField(f); });
    });

    const show = (el, html) => { alertOk.classList.remove('show'); alertErr.classList.remove('show'); if (html) el.querySelector('.alert-text').innerHTML = html; el.classList.add('show'); el.scrollIntoView({ block: 'nearest', behavior: reduceMotion ? 'auto' : 'smooth' }); };

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      alertOk.classList.remove('show'); alertErr.classList.remove('show');
      const fields = $$('input, select, textarea', form).filter((f) => rules[f.name]);
      const results = fields.map(validateField);
      const firstBad = fields[results.indexOf(false)];
      if (firstBad) { firstBad.focus(); return; }

      const data = new FormData(form);
      data.append('csrf_token', csrf);
      data.append('elapsed', String(Date.now() - fieldLoadedAt));
      submitBtn.classList.add('is-loading'); submitBtn.disabled = true;
      $('.btn-label', submitBtn).textContent = 'Sending';
      try {
        const res = await fetch(endpoint, { method: 'POST', body: data, credentials: 'same-origin', headers: { Accept: 'application/json' } });
        const ct = res.headers.get('content-type') || '';
        if (!ct.includes('application/json')) throw new Error('no-backend');
        const json = await res.json();
        if (json.success) {
          show(alertOk, 'Thank you! Your message has been sent successfully.');
          form.reset(); $$('.field', form).forEach((f) => f.classList.remove('is-valid', 'has-error'));
          fieldLoadedAt = Date.now(); loadToken();
        } else {
          const msg = json.errors ? Object.values(json.errors).join(' ') : (json.message || 'Something went wrong.');
          if (json.errors) Object.entries(json.errors).forEach(([k, v]) => { const f = form.elements[k]; if (f) setErr(f, v); });
          show(alertErr, msg);
        }
      } catch (err) {
        const mail = form.dataset.mailto || '';
        show(alertErr, 'The message could not be sent from this server. ' + (mail ? `Email me directly at <a href="mailto:${mail}">${mail}</a>.` : 'Please try again shortly.'));
      } finally {
        submitBtn.classList.remove('is-loading'); submitBtn.disabled = false;
        $('.btn-label', submitBtn).textContent = 'Send Message';
      }
    });
  }

  /* ---------- Footer year ---------- */
  $$('[data-year]').forEach((el) => { el.textContent = new Date().getFullYear() < 2026 ? '2026' : new Date().getFullYear(); });
})();
