"""Generates placeholder SVG images (profile + project device mockups).
Run:  python3 tools/gen_assets.py
Replace any generated image later by dropping a real file with the same base name
(and updating the extension in the HTML if it is not .svg)."""
import os, random

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "images")
os.makedirs(OUT, exist_ok=True)


# ---------------------------------------------------------------- UI renderers
def ui(kind, x, y, w, h, c1, c2, light, seed):
    rnd = random.Random(seed)
    bg = "#f4f5fb" if light else "#0f1530"
    fg = "#1b2142" if light else "#dfe6ff"
    g = f"url(#g{seed})"
    s = [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{bg}"/>']
    nh = h * 0.09
    s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{nh}" fill="{fg}" opacity=".06"/>')
    s.append(f'<circle cx="{x + w*0.05}" cy="{y + nh/2}" r="{nh*0.22}" fill="{g}"/>')
    for i in range(3):
        s.append(f'<rect x="{x + w*(0.62 + i*0.1)}" y="{y + nh*0.42}" width="{w*0.07}" height="{nh*0.16}" rx="{nh*0.08}" fill="{fg}" opacity=".35"/>')
    top = y + nh

    if kind == "site":
        for i, (bw, op) in enumerate([(0.42, .9), (0.34, .9), (0.26, .45)]):
            s.append(f'<rect x="{x + w*0.07}" y="{top + h*(0.08 + i*0.075)}" width="{w*bw}" height="{h*0.04}" rx="{h*0.02}" fill="{fg}" opacity="{op}"/>')
        s.append(f'<rect x="{x + w*0.07}" y="{top + h*0.33}" width="{w*0.2}" height="{h*0.06}" rx="{h*0.03}" fill="{g}"/>')
        cx, cy, r = x + w*0.76, top + h*0.2, min(w, h)*0.19
        s.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{g}"/>')
        s.append(f'<circle cx="{cx}" cy="{cy}" r="{r*1.35}" fill="none" stroke="{c2}" stroke-opacity=".5" stroke-dasharray="4 6"/>')
        cw = (w*0.86 - 2*w*0.03) / 3
        for i in range(3):
            cx0 = x + w*0.07 + i*(cw + w*0.03)
            s.append(f'<rect x="{cx0}" y="{y + h*0.66}" width="{cw}" height="{h*0.25}" rx="{h*0.02}" fill="{fg}" opacity=".08"/>')
            s.append(f'<rect x="{cx0}" y="{y + h*0.66}" width="{cw}" height="{h*0.05}" rx="{h*0.02}" fill="{g}" opacity=".85"/>')
            s.append(f'<rect x="{cx0 + cw*0.1}" y="{y + h*0.76}" width="{cw*0.6}" height="{h*0.025}" rx="3" fill="{fg}" opacity=".55"/>')
            s.append(f'<rect x="{cx0 + cw*0.1}" y="{y + h*0.82}" width="{cw*0.8}" height="{h*0.02}" rx="3" fill="{fg}" opacity=".25"/>')
    elif kind == "shop":
        s.append(f'<rect x="{x + w*0.05}" y="{top + h*0.04}" width="{w*0.9}" height="{h*0.27}" rx="{h*0.025}" fill="{g}"/>')
        s.append(f'<rect x="{x + w*0.1}" y="{top + h*0.09}" width="{w*0.34}" height="{h*0.045}" rx="4" fill="#fff" opacity=".95"/>')
        s.append(f'<rect x="{x + w*0.1}" y="{top + h*0.155}" width="{w*0.24}" height="{h*0.025}" rx="4" fill="#fff" opacity=".6"/>')
        s.append(f'<rect x="{x + w*0.1}" y="{top + h*0.215}" width="{w*0.14}" height="{h*0.05}" rx="{h*0.025}" fill="#fff"/>')
        s.append(f'<circle cx="{x + w*0.78}" cy="{top + h*0.175}" r="{min(w,h)*0.13}" fill="#fff" opacity=".18"/>')
        cols = 4 if w > 300 else 2
        rows = 1 if w > 300 else 2
        gap = w * 0.025
        cw = (w*0.9 - gap*(cols-1)) / cols
        ch = h*0.3 if rows == 1 else h*0.2
        for r_ in range(rows):
            for c in range(cols):
                px = x + w*0.05 + c*(cw + gap)
                py = top + h*0.36 + r_*(ch + gap)
                s.append(f'<rect x="{px}" y="{py}" width="{cw}" height="{ch}" rx="{h*0.02}" fill="{fg}" opacity=".07"/>')
                s.append(f'<circle cx="{px + cw/2}" cy="{py + ch*0.38}" r="{min(cw, ch)*0.26}" fill="{g}" opacity="{.5 + rnd.random()*.5:.2f}"/>')
                s.append(f'<rect x="{px + cw*0.12}" y="{py + ch*0.74}" width="{cw*0.5}" height="{ch*0.07}" rx="3" fill="{fg}" opacity=".5"/>')
                s.append(f'<rect x="{px + cw*0.12}" y="{py + ch*0.86}" width="{cw*0.3}" height="{ch*0.06}" rx="3" fill="{c2}" opacity=".9"/>')
    elif kind == "dash":
        sw = w * 0.2
        s.append(f'<rect x="{x}" y="{top}" width="{sw}" height="{h - nh}" fill="{fg}" opacity=".05"/>')
        for i in range(6):
            s.append(f'<rect x="{x + sw*0.15}" y="{top + h*(0.06 + i*0.07)}" width="{sw*(0.7 if i else 0.55)}" height="{h*0.03}" rx="4" fill="{g if i == 0 else fg}" opacity="{1 if i == 0 else .3}"/>')
        mx = x + sw + w*0.03
        mw = w - sw - w*0.06
        cw = (mw - 2*w*0.02) / 3
        for i in range(3):
            px = mx + i*(cw + w*0.02)
            s.append(f'<rect x="{px}" y="{top + h*0.04}" width="{cw}" height="{h*0.16}" rx="{h*0.02}" fill="{fg}" opacity=".08"/>')
            s.append(f'<rect x="{px + cw*0.1}" y="{top + h*0.075}" width="{cw*0.35}" height="{h*0.022}" rx="3" fill="{fg}" opacity=".4"/>')
            s.append(f'<rect x="{px + cw*0.1}" y="{top + h*0.12}" width="{cw*0.55}" height="{h*0.04}" rx="4" fill="{g}"/>')
        cy0 = top + h*0.25
        ch = h*0.55
        s.append(f'<rect x="{mx}" y="{cy0}" width="{mw}" height="{ch}" rx="{h*0.02}" fill="{fg}" opacity=".06"/>')
        n = 10 if w > 300 else 6
        bw = mw*0.82/n
        pts = []
        for i in range(n):
            bh = ch*(0.25 + rnd.random()*0.55)
            bx = mx + mw*0.07 + i*bw*1.2
            s.append(f'<rect x="{bx}" y="{cy0 + ch*0.92 - bh}" width="{bw*0.75}" height="{bh}" rx="3" fill="{g}" opacity=".85"/>')
            pts.append(f"{bx + bw*0.37},{cy0 + ch*0.92 - bh - ch*0.08}")
        s.append(f'<polyline points="{" ".join(pts)}" fill="none" stroke="{c2}" stroke-width="2" stroke-linejoin="round"/>')
    else:  # landing
        s.append(f'<circle cx="{x + w*0.2}" cy="{top + h*0.2}" r="{h*0.3}" fill="{c1}" opacity=".35"/>')
        s.append(f'<circle cx="{x + w*0.85}" cy="{top + h*0.35}" r="{h*0.28}" fill="{c2}" opacity=".3"/>')
        for i, bw in enumerate([0.62, 0.48]):
            s.append(f'<rect x="{x + w*(1-bw)/2}" y="{top + h*(0.1 + i*0.1)}" width="{w*bw}" height="{h*0.065}" rx="{h*0.03}" fill="{fg}" opacity=".92"/>')
        s.append(f'<rect x="{x + w*0.3}" y="{top + h*0.34}" width="{w*0.4}" height="{h*0.025}" rx="4" fill="{fg}" opacity=".35"/>')
        s.append(f'<rect x="{x + w*0.4}" y="{top + h*0.42}" width="{w*0.2}" height="{h*0.07}" rx="{h*0.035}" fill="{g}"/>')
        for i in range(4):
            s.append(f'<rect x="{x + w*(0.1 + i*0.22)}" y="{top + h*0.62}" width="{w*0.18}" height="{h*0.2}" rx="{h*0.02}" fill="{fg}" opacity=".09"/>')
            s.append(f'<circle cx="{x + w*(0.19 + i*0.22)}" cy="{top + h*0.69}" r="{h*0.03}" fill="{c2 if i % 2 else c1}"/>')
            s.append(f'<rect x="{x + w*(0.12 + i*0.22)}" y="{top + h*0.76}" width="{w*0.14}" height="{h*0.02}" rx="3" fill="{fg}" opacity=".45"/>')
    return "\n".join(s)


# ---------------------------------------------------------------- device frames
def project_svg(device, kind, c1, c2, light, seed, chips):
    rnd = random.Random(seed)
    d = [f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 560" role="img">
<defs>
<linearGradient id="g{seed}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/></linearGradient>
<radialGradient id="r1{seed}" cx=".2" cy=".15" r=".7"><stop offset="0" stop-color="{c1}" stop-opacity=".55"/><stop offset="1" stop-color="{c1}" stop-opacity="0"/></radialGradient>
<radialGradient id="r2{seed}" cx=".9" cy=".95" r=".7"><stop offset="0" stop-color="{c2}" stop-opacity=".5"/><stop offset="1" stop-color="{c2}" stop-opacity="0"/></radialGradient>
<pattern id="grid{seed}" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M40 0H0V40" fill="none" stroke="#fff" stroke-opacity=".05"/></pattern>
<filter id="sh{seed}" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="24" stdDeviation="22" flood-color="#000" flood-opacity=".55"/></filter>
</defs>
<rect width="800" height="560" fill="#080b18"/>
<rect width="800" height="560" fill="url(#r1{seed})"/><rect width="800" height="560" fill="url(#r2{seed})"/>
<rect width="800" height="560" fill="url(#grid{seed})"/>''']

    def clip(cid, x, y, w, h, rx, extra=""):
        d.append(f'<clipPath id="{cid}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}"/></clipPath>')

    frame = "#141a36"
    stroke = "#2e3868"
    if device == "desktop":
        d.append(f'<g filter="url(#sh{seed})"><rect x="110" y="70" width="580" height="350" rx="16" fill="{frame}" stroke="{stroke}"/>'
                 f'<polygon points="370,420 430,420 446,468 354,468" fill="#192043"/><rect x="316" y="468" width="168" height="10" rx="5" fill="#222b57"/></g>')
        clip(f"c{seed}", 124, 84, 552, 322, 6)
        d.append(f'<g clip-path="url(#c{seed})">{ui(kind, 124, 84, 552, 322, c1, c2, light, seed)}</g>')
    elif device == "laptop":
        d.append(f'<g filter="url(#sh{seed})"><rect x="160" y="90" width="480" height="300" rx="14" fill="{frame}" stroke="{stroke}"/>'
                 f'<rect x="90" y="390" width="620" height="18" rx="9" fill="#1c2349" stroke="{stroke}"/><rect x="350" y="390" width="100" height="6" rx="3" fill="#0f1430"/></g>')
        clip(f"c{seed}", 172, 102, 456, 276, 5)
        d.append(f'<g clip-path="url(#c{seed})">{ui(kind, 172, 102, 456, 276, c1, c2, light, seed)}</g>')
    elif device == "tablet":
        d.append(f'<g filter="url(#sh{seed})"><rect x="150" y="95" width="500" height="360" rx="28" fill="{frame}" stroke="{stroke}"/></g>'
                 f'<circle cx="162" cy="275" r="3" fill="#2e3868"/>')
        clip(f"c{seed}", 172, 115, 456, 320, 12)
        d.append(f'<g clip-path="url(#c{seed})">{ui(kind, 172, 115, 456, 320, c1, c2, light, seed)}</g>')
    else:  # mobile: main phone + secondary phone
        d.append(f'<g transform="rotate(-9 240 300)" filter="url(#sh{seed})"><rect x="150" y="120" width="170" height="340" rx="28" fill="{frame}" stroke="{stroke}"/></g>')
        d.append(f'<clipPath id="cb{seed}"><rect x="160" y="130" width="150" height="320" rx="20"/></clipPath>')
        d.append(f'<g transform="rotate(-9 240 300)"><g clip-path="url(#cb{seed})">{ui("shop" if kind != "shop" else "dash", 160, 130, 150, 320, c2, c1, not light, seed + 100)}</g></g>')
        d.append(f'<linearGradient id="g{seed + 100}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{c2}"/><stop offset="1" stop-color="{c1}"/></linearGradient>')
        d.append(f'<g filter="url(#sh{seed})"><rect x="318" y="48" width="210" height="450" rx="36" fill="{frame}" stroke="{stroke}"/></g>')
        clip(f"c{seed}", 330, 60, 186, 426, 26)
        d.append(f'<g clip-path="url(#c{seed})">{ui(kind, 330, 60, 186, 426, c1, c2, light, seed)}</g>')
        d.append(f'<rect x="392" y="66" width="60" height="14" rx="7" fill="#05070f"/>')

    # floating code chips
    for (txt, cx, cy) in chips:
        wv = 22 + len(txt) * 8.2
        d.append(f'<g transform="translate({cx} {cy})"><rect width="{wv}" height="30" rx="15" fill="#0c1128" fill-opacity=".85" stroke="{c1}" stroke-opacity=".55"/>'
                 f'<text x="{wv/2}" y="19.5" text-anchor="middle" font-family="ui-monospace,Menlo,Consolas,monospace" font-size="12" fill="#cfe0ff">{txt}</text></g>')
    d.append("</svg>")
    return "\n".join(d)


PROJECTS = [
    # file, device, kind, c1, c2, light, seed, chips
    ("project-restaurant", "desktop", "site", "#f59e0b", "#ef4444", True, 11, [("&lt;?php wp_head(); ?&gt;", 40, 60), ("Elementor", 590, 440)]),
    ("project-woocommerce", "laptop", "shop", "#8b5cf6", "#22d3ee", True, 22, [("WooCommerce", 560, 52), ("add_to_cart()", 40, 430)]),
    ("project-business", "tablet", "landing", "#3b82f6", "#22d3ee", False, 33, [("custom theme", 50, 58), ("ACF Pro", 600, 470)]),
    ("project-management", "laptop", "dash", "#22d3ee", "#8b5cf6", False, 44, [("PDO::prepare()", 40, 60), ("MySQL", 640, 440)]),
    ("project-fitness", "mobile", "site", "#10b981", "#22d3ee", False, 55, [("mobile first", 560, 70), ("REST API", 590, 430)]),
    ("project-realestate", "tablet", "shop", "#ec4899", "#8b5cf6", True, 66, [("CPT + ACF", 50, 60), ("WP_Query", 590, 470)]),
    ("project-invoice", "desktop", "dash", "#3b82f6", "#8b5cf6", False, 77, [("JWT auth", 50, 58), ("PHP 8.3", 610, 440)]),
    ("project-agency", "laptop", "landing", "#a855f7", "#3b82f6", False, 88, [("Figma → WP", 40, 56), ("GSAP", 640, 440)]),
]
for f, dev, kind, c1, c2, light, seed, chips in PROJECTS:
    with open(os.path.join(OUT, f + ".svg"), "w", encoding="utf-8") as fh:
        fh.write(project_svg(dev, kind, c1, c2, light, seed, chips))

# ---------------------------------------------------------------- profile placeholder
profile = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 1000" role="img">
<defs>
<radialGradient id="b1" cx=".25" cy=".2" r=".8"><stop offset="0" stop-color="#3b82f6" stop-opacity=".55"/><stop offset="1" stop-color="#3b82f6" stop-opacity="0"/></radialGradient>
<radialGradient id="b2" cx=".85" cy=".7" r=".8"><stop offset="0" stop-color="#8b5cf6" stop-opacity=".55"/><stop offset="1" stop-color="#8b5cf6" stop-opacity="0"/></radialGradient>
<radialGradient id="b3" cx=".5" cy=".95" r=".6"><stop offset="0" stop-color="#22d3ee" stop-opacity=".35"/><stop offset="1" stop-color="#22d3ee" stop-opacity="0"/></radialGradient>
<linearGradient id="skin" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3a4678"/><stop offset="1" stop-color="#1b2247"/></linearGradient>
<linearGradient id="rim" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#22d3ee"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient>
<pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse"><path d="M50 0H0V50" fill="none" stroke="#fff" stroke-opacity=".05"/></pattern>
<linearGradient id="fade" x1="0" y1="0" x2="0" y2="1"><stop offset=".7" stop-color="#070a14" stop-opacity="0"/><stop offset="1" stop-color="#070a14"/></linearGradient>
</defs>
<rect width="800" height="1000" fill="#090d1c"/>
<rect width="800" height="1000" fill="url(#b1)"/><rect width="800" height="1000" fill="url(#b2)"/><rect width="800" height="1000" fill="url(#b3)"/>
<rect width="800" height="1000" fill="url(#grid)"/>
<g font-family="ui-monospace,Menlo,Consolas,monospace" font-size="15" fill="#7da2ff" opacity=".35">
<text x="520" y="150">function build() {</text><text x="540" y="176">return performance;</text><text x="520" y="202">}</text>
<text x="60" y="820">add_action('init', 'launch');</text><text x="60" y="846">// WordPress &amp; PHP</text>
</g>
<path d="M130 1000 C130 800 230 700 400 690 C570 700 670 800 670 1000Z" fill="url(#skin)"/>
<path d="M130 1000 C130 800 230 700 400 690 C570 700 670 800 670 1000" fill="none" stroke="url(#rim)" stroke-width="3" opacity=".8"/>
<rect x="350" y="560" width="100" height="150" rx="40" fill="#252e5a"/>
<ellipse cx="400" cy="420" rx="135" ry="165" fill="url(#skin)"/>
<path d="M265 420 C265 255 535 255 535 420" fill="none" stroke="url(#rim)" stroke-width="3" opacity=".7"/>
<text x="400" y="935" text-anchor="middle" font-family="ui-monospace,Menlo,Consolas,monospace" font-size="16" fill="#9fb2ff" opacity=".75">placeholder: add images/laxmon.jpg</text>
<rect width="800" height="1000" fill="url(#fade)"/>
</svg>'''
open(os.path.join(OUT, "profile-placeholder.svg"), "w", encoding="utf-8").write(profile)

fav = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3b82f6"/><stop offset=".6" stop-color="#8b5cf6"/><stop offset="1" stop-color="#22d3ee"/></linearGradient></defs><rect width="64" height="64" rx="16" fill="url(#g)"/><text x="32" y="43" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="30" fill="#fff">LM</text></svg>'''
open(os.path.join(OUT, "favicon.svg"), "w", encoding="utf-8").write(fav)
print("assets ok")
