"""Builds the five static HTML pages from shared partials.
Run:  python3 tools/build.py
Edit copy/content in this file, then re-run to regenerate. The output HTML is plain static files."""
import os, html as _h

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE_URL = "https://laxmon.netlify.com/"
EMAIL = "contact@laxmonmistry.com"  # placeholder: replace with your real email
SOCIAL = {
    "github": ("GitHub", "https://github.com/"),
    "linkedin": ("LinkedIn", "https://www.linkedin.com/"),
    "fiverr": ("Fiverr", "https://www.fiverr.com/"),
    "upwork": ("Upwork", "https://www.upwork.com/"),
}
DEMO = "https://laxmon.netlify.com/"
PHOTO = ('<img src="images/laxmon.jpg" onerror="this.onerror=null;this.src=\'images/profile-placeholder.svg\'" '
         'alt="Laxmon Mistry, WordPress and PHP developer" width="800" height="1000" {extra}>')

esc = _h.escape


# ------------------------------------------------------------------ icons
ICONS = {
    "arrow": '<path d="M5 12h14M13 6l6 6-6 6"/>',
    "close": '<path d="M6 6l12 12M18 6L6 18"/>',
    "code": '<path d="M8 8l-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/>',
    "wp": '<circle cx="12" cy="12" r="9"/><path d="M6.8 8.2L10.2 17.6l2-5.8 2.2 5.8 3-9.4M6.5 8.2h4.2M13.8 8.2h3.9"/>',
    "php": '<ellipse cx="12" cy="12" rx="10" ry="6.2"/><text x="12" y="14.6" text-anchor="middle">php</text>',
    "layers": '<path d="M12 3l9 5-9 5-9-5 9-5zM3 12.5l9 5 9-5M3 16.5l9 5 9-5"/>',
    "cart": '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.7 12.4a1 1 0 001 .8h9.1a1 1 0 001-.8L20.5 7H6"/>',
    "bug": '<rect x="8" y="7" width="8" height="12" rx="4"/><path d="M12 7V4M8 11H4M16 11h4M8 16H4M16 16h4M9 4l3 2 3-2"/>',
    "cpu": '<rect x="6" y="6" width="12" height="12" rx="2"/><rect x="10" y="10" width="4" height="4"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
    "bolt": '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
    "brush": '<path d="M12 3a9 9 0 100 18c1.4 0 2-1 2-2 0-1.4-1-1.6-1-3 0-1 1-2 2.5-2H18a3 3 0 003-3c0-5-4-8-9-8z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7" r="1"/><circle cx="15" cy="7.5" r="1"/>',
    "mail": '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    "pin": '<path d="M12 21s7-6.2 7-12a7 7 0 10-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/>',
    "clock": '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    "brief": '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2M3 13h18"/>',
    "check": '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    "github": '<path d="M9 19c-4 1.3-4-2-6-2.5M15 21v-3.5c0-1 .1-1.5-.5-2.3 2.8-.3 5.5-1.4 5.5-6A4.6 4.6 0 0018.8 6 4.2 4.2 0 0018.7 3S17.5 2.7 15 4.4a12 12 0 00-6 0C6.5 2.7 5.3 3 5.3 3a4.2 4.2 0 00-.1 3A4.6 4.6 0 004 9.2c0 4.6 2.7 5.7 5.5 6-.6.6-.6 1.2-.5 2.3V21"/>',
    "linkedin": '<path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-4 0v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/>',
    "fiverr": '<rect x="3" y="3" width="18" height="18" rx="5"/><text x="12" y="15.4" text-anchor="middle" style="font-size:9px">fi</text>',
    "upwork": '<rect x="3" y="3" width="18" height="18" rx="5"/><text x="12" y="15.4" text-anchor="middle" style="font-size:9px">Up</text>',
    "shield": '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    "globe": '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    "star": '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
    "send": '<path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/>',
    "target": '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    "users": '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6M16 4.5a3.5 3.5 0 010 7M18.5 14.5c2 .8 3 2.6 3 5.5"/>',
    "layout": '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
    "gauge": '<path d="M4 18a9 9 0 1116 0M12 18l4-6"/>',
    "monitor": '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
    "laptop": '<rect x="5" y="5" width="14" height="10" rx="1.5"/><path d="M2 19h20"/>',
    "tablet": '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M11 18h2"/>',
    "phone": '<rect x="7" y="2" width="10" height="20" rx="2.5"/><path d="M11 18h2"/>',
    "db": '<ellipse cx="12" cy="5.5" rx="8" ry="3"/><path d="M4 5.5v13c0 1.7 3.6 3 8 3s8-1.3 8-3v-13M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
    "figma": '<path d="M8 3h4a3 3 0 010 6H8zM12 3h4a3 3 0 010 6h-4zM8 9h4a3 3 0 010 6H8a3 3 0 010-6zM8 15h4v3a3 3 0 11-4-2.8z"/>',
}


def ic(name, cls=""):
    return f'<svg class="icon {cls}" aria-hidden="true"><use href="#i-{name}"/></svg>'


def sprite():
    s = "".join(f'<symbol id="i-{k}" viewBox="0 0 24 24">{v}</symbol>' for k, v in ICONS.items())
    return f'<svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">{s}</svg>'


# ------------------------------------------------------------------ data
NAV = [("index.html", "Home", "home"), ("about.html", "About", "about"), ("services.html", "Services", "services"),
       ("projects.html", "Projects", "projects"), ("contact.html", "Contact", "contact")]

TECH = [
    ("Wp", "WordPress", "Themes, plugins, multisite", "#3b82f6", 95),
    ("PHP", "PHP", "OOP, PDO, REST, MVC", "#8b5cf6", 90),
    ("JS", "JavaScript", "ES6+, DOM, Fetch, AJAX", "#eab308", 82),
    ("H5", "HTML5", "Semantic, accessible markup", "#f97316", 96),
    ("C3", "CSS3", "Grid, Flexbox, animation", "#2563eb", 94),
    ("El", "Elementor", "Pro, custom widgets", "#ec4899", 92),
    ("Wc", "WooCommerce", "Stores, payments, hooks", "#a855f7", 88),
    ("DB", "MySQL", "Schema design, queries", "#06b6d4", 84),
    ("Git", "Git", "Branching, GitHub flow", "#ef4444", 86),
    ("API", "REST API", "Integrations, webhooks", "#10b981", 87),
]

SERVICES = [
    ("wordpress-website-development", "wp", "WordPress Website Development", "WordPress Website Development",
     "Complete business websites on WordPress, from structure and content modelling to launch. Built to be fast, secure and easy for your team to update.",
     ["Custom page layouts", "Editor-friendly content blocks", "Security hardening", "SEO-ready structure"],
     ["WordPress", "PHP", "ACF", "MySQL"], "From a clean install to a site you can edit without calling a developer."),
    ("custom-wordpress-theme-development", "code", "Custom WordPress Theme Development", "Custom WordPress Theme Development",
     "Hand-coded themes with no page-builder bloat. Template hierarchy, custom post types and reusable components that match your design exactly.",
     ["Pixel-accurate to your design", "Custom post types & taxonomies", "Block-editor compatible", "Child theme or from scratch"],
     ["PHP", "WP Theme API", "SCSS", "JavaScript"], ""),
    ("php-web-development", "php", "PHP Web Development", "PHP Web Development",
     "Custom web applications in modern PHP: admin panels, booking tools, dashboards and internal systems that fit how your business actually works.",
     ["Clean OOP architecture", "Secure authentication & roles", "MySQL with PDO", "Admin dashboards & reports"],
     ["PHP 8", "MySQL", "PDO", "REST"], ""),
    ("elementor-website-development", "layers", "Elementor Website Development", "Elementor Website Development",
     "Elementor sites that look custom and stay manageable. Global styles, reusable templates and lightweight output so pages stay quick.",
     ["Global design system", "Dynamic content & loops", "Custom widgets when needed", "Optimised for Core Web Vitals"],
     ["Elementor Pro", "ACF", "CSS3", "JavaScript"], ""),
    ("woocommerce-development", "cart", "WooCommerce Development", "WooCommerce Development",
     "Online stores built to convert: product setup, payment gateways, shipping rules and custom checkout flows that reduce abandoned carts.",
     ["Payment & shipping setup", "Custom product pages", "Checkout optimisation", "Hooks & custom extensions"],
     ["WooCommerce", "PHP", "Stripe / PayPal", "REST"], ""),
    ("figma-psd-xd-to-wordpress", "figma", "Figma / PSD / XD to WordPress", "Figma / PSD / XD to WordPress",
     "Send me your Figma, Photoshop or Adobe XD file and get back a responsive, pixel-accurate WordPress site that behaves like the design.",
     ["Pixel-perfect conversion", "Fully responsive", "Animations & micro-interactions", "Cross-browser tested"],
     ["Figma", "WordPress", "Elementor", "CSS3"], ""),
    ("wordpress-bug-fixing", "bug", "WordPress Bug Fixing", "WordPress Bug Fixing",
     "Broken layout, plugin conflict, white screen or a site that was hacked? I find the root cause, fix it and leave notes so it stays fixed.",
     ["Plugin & theme conflicts", "PHP errors & white screen", "Malware cleanup", "Post-fix monitoring"],
     ["WordPress", "PHP", "Debugging", "Git"], ""),
    ("api-ai-integration", "cpu", "API & AI Integration", "API & AI Integration",
     "Connect your site to the tools you use: payment, CRM, email, maps and AI services. Add chat assistants, content helpers and automations.",
     ["Third-party REST integrations", "AI chat & content tools", "Webhooks & automation", "Secure key handling"],
     ["REST API", "PHP", "JavaScript", "OpenAI API"], ""),
    ("website-speed-optimization", "gauge", "Website Speed Optimization", "Website Speed Optimization",
     "A faster site ranks better and converts more. I audit, profile and fix what slows you down, then prove it with before-and-after scores.",
     ["Core Web Vitals fixes", "Image & font optimisation", "Caching & CDN setup", "Database & plugin clean-up"],
     ["Lighthouse", "WP Rocket", "Cloudflare", "PHP"], ""),
    ("wordpress-customization", "brush", "WordPress Customization", "WordPress Customization",
     "Need a feature your theme or plugin does not offer? I customise what you have: custom fields, new sections, plugin tweaks and workflow changes.",
     ["Custom fields & forms", "Plugin modifications", "Theme feature additions", "Admin experience improvements"],
     ["PHP", "ACF", "Hooks & filters", "JavaScript"], ""),
]
HOME_SERVICES = [
    ("wordpress-website-development", "wp", "WordPress Development", "Business sites, blogs and portals built on a clean, secure and scalable WordPress foundation."),
    ("php-web-development", "php", "Custom PHP Development", "Tailor-made PHP applications, dashboards and integrations built around your workflow."),
    ("elementor-website-development", "layers", "Elementor & WooCommerce", "Visually rich pages and high-converting online stores your team can manage on its own."),
    ("wordpress-customization", "brush", "Website Customization", "Custom features, plugin tweaks and design changes added to a site you already have."),
]

PROJECTS = [
    dict(id=1, file="project-restaurant", title="Saffron & Co. Restaurant Website", cat="WordPress", cats="wordpress elementor", device="Desktop", dicon="monitor",
         desc="A rich, appetising restaurant site with online table booking, a seasonal menu manager and a gallery that loads fast on mobile.",
         tags=["WordPress", "Elementor", "ACF", "Table booking"],
         long="Saffron & Co. needed a site that looked as good as the food and let guests book without calling. I built a lightweight WordPress site with an editable menu system, an online reservation form and an image gallery tuned for mobile data.",
         features=["Menu manager with dietary tags", "Reservation form with email confirmation", "Opening-hours widget that updates itself", "Mobile page weight under 1.2 MB"],
         meta=[("Type", "Business website"), ("Role", "Design to development"), ("Timeline", "3 weeks"), ("Stack", "WordPress + Elementor")]),
    dict(id=2, file="project-woocommerce", title="Urban Cart WooCommerce Store", cat="WooCommerce", cats="woocommerce wordpress", device="Laptop", dicon="laptop",
         desc="A conversion-focused online store with fast filtering, a streamlined one-page checkout and multiple payment gateways.",
         tags=["WooCommerce", "PHP", "Stripe", "AJAX filters"],
         long="Urban Cart's checkout was losing buyers. I rebuilt the product pages and condensed checkout into a single step, added live AJAX product filters and connected card and wallet payments.",
         features=["One-page checkout flow", "AJAX filters by size, colour and price", "Stripe and PayPal payments", "Abandoned-cart email trigger"],
         meta=[("Type", "E-commerce"), ("Role", "Theme + store build"), ("Timeline", "5 weeks"), ("Stack", "WooCommerce + PHP")]),
    dict(id=3, file="project-business", title="BrightPath Consulting Website", cat="Custom Development", cats="wordpress custom", device="Tablet", dicon="tablet",
         desc="A confident corporate website on a hand-coded theme with service pages, case studies and a lead-capture funnel.",
         tags=["Custom theme", "PHP", "SCSS", "Lead forms"],
         long="BrightPath wanted a site that felt premium and was easy to extend. I coded a custom theme with reusable page sections so their team can compose new landing pages without a developer.",
         features=["Reusable section library", "Case-study custom post type", "Lead form with CRM hand-off", "Lighthouse score 95+"],
         meta=[("Type", "Corporate website"), ("Role", "Custom theme"), ("Timeline", "4 weeks"), ("Stack", "Custom WP theme")]),
    dict(id=4, file="project-management", title="ServiceDesk Pro Management System", cat="PHP", cats="php custom", device="Laptop", dicon="laptop",
         desc="A custom PHP ticketing and job-management system with role-based access, status tracking and monthly reports.",
         tags=["PHP 8", "MySQL", "PDO", "Chart.js"],
         long="A field-service team was juggling jobs in spreadsheets. I built a secure PHP application where staff create tickets, managers assign jobs and owners see live performance reports.",
         features=["Role-based permissions", "Ticket lifecycle with audit trail", "Exportable monthly reports", "Prepared statements throughout"],
         meta=[("Type", "Web application"), ("Role", "Full-stack PHP"), ("Timeline", "7 weeks"), ("Stack", "PHP + MySQL")]),
    dict(id=5, file="project-fitness", title="Fitora Gym Membership Platform", cat="WooCommerce", cats="woocommerce elementor wordpress", device="Mobile", dicon="phone",
         desc="A mobile-first gym website with class schedules, membership plans sold through WooCommerce and a member area.",
         tags=["WooCommerce", "Elementor", "Subscriptions", "REST API"],
         long="Fitora wanted members to sign up from their phones. I built a mobile-first site where visitors browse classes, buy recurring memberships and manage their plan in an account area.",
         features=["Recurring membership billing", "Live class timetable", "Member dashboard", "Thumb-friendly mobile navigation"],
         meta=[("Type", "Membership site"), ("Role", "Design + build"), ("Timeline", "4 weeks"), ("Stack", "WooCommerce + Elementor")]),
    dict(id=6, file="project-realestate", title="Atlas Real Estate Listings", cat="Custom Development", cats="wordpress custom", device="Tablet", dicon="tablet",
         desc="A property listing portal with custom post types, advanced search, map-ready data and an agent enquiry system.",
         tags=["Custom post types", "WP_Query", "ACF Pro", "JavaScript"],
         long="Atlas needed searchable property listings that agents could update easily. I modelled properties as custom post types and wrote a fast filter by price, location and bedrooms.",
         features=["Advanced multi-filter search", "Agent profiles & enquiries", "Image galleries with lazy loading", "Bulk import from CSV"],
         meta=[("Type", "Listings portal"), ("Role", "Custom development"), ("Timeline", "6 weeks"), ("Stack", "WordPress + ACF Pro")]),
    dict(id=7, file="project-invoice", title="InvoiceFlow Billing Application", cat="PHP", cats="php custom", device="Desktop", dicon="monitor",
         desc="A secure PHP invoicing app for freelancers with recurring invoices, PDF export, payment status and an API.",
         tags=["PHP 8", "REST API", "JWT", "MySQL"],
         long="InvoiceFlow lets small studios create, send and track invoices. I designed the database, built a JSON API with token authentication and a clean dashboard on top of it.",
         features=["Recurring invoices", "PDF generation", "JWT-secured REST API", "Payment status dashboard"],
         meta=[("Type", "SaaS-style app"), ("Role", "Backend + dashboard"), ("Timeline", "8 weeks"), ("Stack", "PHP + MySQL")]),
    dict(id=8, file="project-agency", title="PixelCraft Agency Website", cat="Elementor", cats="wordpress elementor custom", device="Laptop", dicon="laptop",
         desc="A bold agency site converted from a Figma design with smooth scroll animations and an animated portfolio grid.",
         tags=["Figma to WP", "Elementor", "GSAP", "Custom CSS"],
         long="PixelCraft's designer delivered a detailed Figma file with motion notes. I rebuilt it in WordPress with custom CSS and light JavaScript animation, matching spacing and type to the pixel.",
         features=["Pixel-accurate Figma conversion", "Scroll-triggered animation", "Animated portfolio grid", "Responsive from 320px up"],
         meta=[("Type", "Agency website"), ("Role", "Figma to WordPress"), ("Timeline", "3 weeks"), ("Stack", "WordPress + Elementor")]),
]

PROCESS = [
    ("Discovery", "We talk goals, audience and what success looks like."),
    ("Planning", "Sitemap, features and a clear scope with timeline."),
    ("Design", "Layouts and visual direction you approve first."),
    ("Development", "Clean, documented code built in iterations."),
    ("Testing", "Devices, browsers, speed and security checks."),
    ("Launch", "Go-live, handover and support after release."),
]


# ------------------------------------------------------------------ shared partials
def head(title, desc, fname, extra_head=""):
    canon = BASE_URL + ("" if fname == "index.html" else fname)
    return f'''<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{esc(title)}</title>
<meta name="description" content="{esc(desc)}">
<meta name="author" content="Laxmon Mistry">
<meta name="theme-color" content="#060914">
<link rel="canonical" href="{canon}">
<link rel="icon" href="images/favicon.svg" type="image/svg+xml">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Laxmon Mistry">
<meta property="og:title" content="{esc(title)}">
<meta property="og:description" content="{esc(desc)}">
<meta property="og:url" content="{canon}">
<meta property="og:image" content="{BASE_URL}images/laxmon.jpg">
<meta name="twitter:card" content="summary_large_image">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;800&family=Manrope:wght@400;500;600;700&family=Syne:wght@600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<script type="application/ld+json">{{"@context":"https://schema.org","@type":"Person","name":"Laxmon Mistry","jobTitle":"WordPress Developer & PHP Developer","url":"{BASE_URL}","sameAs":["https://github.com/","https://www.linkedin.com/"]}}</script>
{extra_head}</head>'''


def header(active):
    links = "".join(
        f'<a href="{f}"{" class=\"is-active\" aria-current=\"page\"" if k == active else ""}>{n}</a>' for f, n, k in NAV)
    mlinks = "".join(
        f'<a href="{f}"{" class=\"is-active\"" if k == active else ""}><span>{n}</span>{ic("arrow")}</a>' for f, n, k in NAV)
    soc = "".join(f'<a href="{u}" target="_blank" rel="noopener noreferrer" aria-label="{n}">{ic(k)}</a>' for k, (n, u) in SOCIAL.items())
    return f'''<div class="mobile-menu" id="mobile-menu" aria-hidden="true">
  <nav aria-label="Mobile">{mlinks}</nav>
  <div class="mobile-menu-foot">
    <a class="btn btn-primary" href="contact.html"><span>Let's Work Together</span>{ic("arrow", "icon-arrow")}</a>
    <div class="socials">{soc}</div>
  </div>
</div>
<header class="site-header" id="top">
  <div class="wrap header-inner">
    <a href="index.html" class="logo" aria-label="Laxmon Mistry, home"><span class="logo-mark">LM</span><span class="logo-word">LAXMON</span></a>
    <nav class="main-nav" aria-label="Primary">{links}</nav>
    <a class="btn btn-primary btn-sm header-cta" href="contact.html"><span>Let's Work Together</span>{ic("arrow", "icon-arrow")}</a>
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="mobile-menu" aria-label="Open menu"><span></span><span></span><span></span></button>
  </div>
</header>'''


def footer():
    nav = "".join(f'<li><a href="{f}">{n}</a></li>' for f, n, k in NAV)
    svc = "".join(f'<li><a href="services.html#{s[0]}">{s[2]}</a></li>' for s in SERVICES[:6])
    soc = "".join(f'<a href="{u}" target="_blank" rel="noopener noreferrer" aria-label="{n}">{ic(k)}</a>' for k, (n, u) in SOCIAL.items())
    return f'''<footer class="site-footer">
  <div class="wrap">
    <div class="footer-grid">
      <div class="footer-brand">
        <h2>LAXMON MISTRY</h2>
        <p>WordPress Developer &amp; PHP Developer building fast, secure and conversion-focused websites.</p>
        <div class="socials">{soc}</div>
      </div>
      <div class="footer-col"><h3>Navigation</h3><ul>{nav}</ul></div>
      <div class="footer-col"><h3>Services</h3><ul>{svc}</ul></div>
      <div class="footer-col contact-col"><h3>Contact</h3><ul>
        <li class="contact-line">{ic("mail")}<a href="mailto:{EMAIL}">{EMAIL}</a></li>
        <li class="contact-line">{ic("globe")}<span>Remote · working with clients worldwide</span></li>
        <li class="contact-line">{ic("clock")}<span>Replies within 24 hours</span></li>
        <li class="contact-line">{ic("brief")}<a href="{DEMO}" target="_blank" rel="noopener noreferrer">laxmon.netlify.com</a></li>
      </ul></div>
    </div>
    <div class="footer-bottom"><span>© 2026 Laxmon Mistry. All Rights Reserved.</span><span>Designed &amp; coded by Laxmon Mistry</span></div>
  </div>
</footer>
<button class="to-top" type="button" aria-label="Back to top">{ic("arrow")}</button>'''


def page(fname, key, title, desc, body, extra_head="", extra_after=""):
    out = head(title, desc, fname, extra_head) + f'''
<body data-page="{key}">
{sprite()}
<a class="skip-link" href="#main">Skip to content</a>
<div class="bg-stage" aria-hidden="true"><div class="bg-grid"></div><span class="blob b1"></span><span class="blob b2"></span><span class="blob b3"></span><canvas id="particles"></canvas></div>
<div class="noise" aria-hidden="true"></div>
<div class="page-wipe" aria-hidden="true"><span>LAXMON</span></div>
<div class="cursor-dot" aria-hidden="true"></div><div class="cursor-ring" aria-hidden="true"></div>
{header(key)}
<main id="main">
{body}
</main>
{footer()}
{extra_after}
<script src="js/main.js" defer></script>
</body>
</html>
'''
    with open(os.path.join(ROOT, fname), "w", encoding="utf-8") as f:
        f.write(out)


# ------------------------------------------------------------------ reusable blocks
def tech_cards():
    out = []
    for i, (g, n, d, hue, lvl) in enumerate(TECH):
        out.append(f'<article class="tech-card glass reveal scale-in tilt" data-tilt="10" style="--hue:{hue};--lvl:{lvl}%;--d:{i*0.05:.2f}s">'
                   f'<div class="tech-glyph" aria-hidden="true">{g}</div><h3>{n}</h3><p>{d}</p>'
                   f'<div class="tech-meter" role="img" aria-label="{n} proficiency {lvl} percent"><i></i></div></article>')
    return '<div class="tech-grid">' + "".join(out) + "</div>"


def project_card(p, modal=False, delay=0):
    tags = "".join(f"<li>{esc(t)}</li>" for t in p["tags"])
    attrs = f' data-cat="{p["cats"]}"' if modal else ""
    details = (f'<button class="btn btn-ghost btn-sm" type="button" data-details="pd-{p["id"]}">View Details</button>' if modal
               else '<a class="btn btn-ghost btn-sm" href="projects.html">View Details</a>')
    return f'''<article class="project-card glass reveal tilt" data-tilt="4"{attrs} id="project-{p["id"]}" style="--d:{delay:.2f}s">
  <div class="project-media">
    <span class="device-tag">{ic(p["dicon"])}{p["device"]} mockup</span>
    <img src="images/{p["file"]}.svg" alt="{esc(p["title"])} shown on a {p["device"].lower()} mockup" width="800" height="560" loading="lazy" decoding="async">
  </div>
  <div class="project-body">
    <span class="project-cat">{p["cat"]}</span>
    <h3>{esc(p["title"])}</h3>
    <p>{esc(p["desc"])}</p>
    <ul class="tags" aria-label="Technologies">{tags}</ul>
    <div class="project-actions">
      <a class="btn btn-primary btn-sm" href="{DEMO}" target="_blank" rel="noopener noreferrer"><span>Live Demo</span>{ic("arrow", "icon-arrow")}</a>
      {details}
    </div>
  </div>
</article>'''


def project_modal_templates():
    out = []
    for p in PROJECTS:
        feats = "".join(f'<li>{ic("check")}<span>{esc(f)}</span></li>' for f in p["features"])
        meta = "".join(f"<div><dt>{k}</dt><dd>{esc(v)}</dd></div>" for k, v in p["meta"])
        tags = "".join(f"<li>{esc(t)}</li>" for t in p["tags"])
        out.append(f'''<div id="pd-{p["id"]}" hidden>
  <div class="modal-media"><img src="images/{p["file"]}.svg" alt="{esc(p["title"])} mockup" width="800" height="560"></div>
  <div class="modal-content">
    <span class="project-cat">{p["cat"]} · {p["device"]} mockup</span>
    <h3 id="modal-title">{esc(p["title"])}</h3>
    <p class="lead">{esc(p["long"])}</p>
    <div class="modal-cols">
      <div><h4 style="margin-bottom:14px;font-size:18px">Key features</h4><ul class="check-list">{feats}</ul></div>
      <div><h4 style="margin-bottom:14px;font-size:18px">Project facts</h4><dl class="meta-list" style="margin:0">{meta}</dl></div>
    </div>
    <ul class="tags">{tags}</ul>
    <div class="project-actions"><a class="btn btn-primary" href="{DEMO}" target="_blank" rel="noopener noreferrer"><span>Live Demo</span>{ic("arrow", "icon-arrow")}</a><a class="btn btn-ghost" href="contact.html">Start a similar project</a></div>
  </div>
</div>''')
    return "\n".join(out)


def cta(title="Have a project in mind?", big="Let's build something amazing together.", btn="Start a Project"):
    return f'''<section class="section-tight" aria-labelledby="cta-title"><div class="wrap">
  <div class="cta-band reveal scale-in">
    <span class="cta-code" style="left:5%;top:14%">&lt;?php launch( $idea ); ?&gt;</span>
    <span class="cta-code" style="right:6%;top:18%;animation-delay:-3s">add_action('init', 'you_and_me');</span>
    <span class="cta-code" style="left:9%;bottom:12%;animation-delay:-5s">// ship it.</span>
    <span class="cta-code" style="right:8%;bottom:14%;animation-delay:-2s">git push origin main</span>
    <span class="badge"><span class="pulse-dot"></span>BOOKING PROJECTS FOR THE NEXT MONTH</span>
    <h2 id="cta-title">{title}</h2>
    <p class="big">{big}</p>
    <a class="btn btn-primary" href="contact.html"><span>{btn}</span>{ic("arrow", "icon-arrow")}</a>
  </div>
</div></section>'''


def hero_hd(crumb, h1, sub):
    return f'''<section class="page-hero"><div class="wrap">
  <nav class="crumbs hero-in" aria-label="Breadcrumb"><a href="index.html">Home</a><span>/</span><span aria-current="page">{crumb}</span></nav>
  <h1 class="hero-in">{h1}</h1>
  <p class="lead hero-in">{sub}</p>
</div></section>'''


# ------------------------------------------------------------------ HOME
def build_home():
    soc = "".join(f'<a href="{u}" target="_blank" rel="noopener noreferrer" aria-label="{n}">{ic(k)}</a>' for k, (n, u) in SOCIAL.items())
    marquee = "".join(f"<span>{t[1]}</span>" for t in TECH)
    svc_cards = "".join(
        f'''<a class="svc-card reveal" href="services.html#{sid}" style="--d:{i*0.08:.2f}s">
  <div class="svc-icon">{ic(icon)}</div><h3>{t}</h3><p>{d}</p>
  <span class="arrow-link">Explore service <span class="arr">{ic("arrow")}</span></span></a>''' for i, (sid, icon, t, d) in enumerate(HOME_SERVICES))
    projs = "".join(project_card(p, delay=(i % 2) * 0.1) for i, p in enumerate(PROJECTS[:4]))
    body = f'''
<section class="hero" aria-labelledby="hero-title"><div class="wrap hero-grid">
  <div class="hero-stagger">
    <span class="badge"><span class="pulse-dot"></span>AVAILABLE FOR FREELANCE PROJECTS</span>
    <h1 id="hero-title"><span>WordPress Developer</span><span class="grad-text">&amp; PHP Developer</span></h1>
    <p class="lead">I design and develop modern, fast, responsive and conversion-focused websites using WordPress, PHP and modern web technologies.</p>
    <div class="hero-actions">
      <a class="btn btn-primary" href="projects.html"><span>View My Work</span>{ic("arrow", "icon-arrow")}</a>
      <a class="btn btn-ghost" href="contact.html"><span>Let's Work Together</span></a>
    </div>
    <div class="hero-meta"><div class="socials">{soc}</div><small>I Build High-Performance WordPress Websites &amp; Custom PHP Solutions.</small></div>
  </div>

  <div class="profile-stage hero-in" aria-label="Laxmon Mistry developer profile">
    <div class="orb" aria-hidden="true"></div>
    <div class="profile-card" data-depth="8"><div class="photo">{PHOTO.format(extra='fetchpriority="high" decoding="async"')}</div></div>
    <div class="float-card fc-stack glass" data-depth="22"><span class="fc-title">CORE STACK</span>
      <ul class="stack-list"><li style="--c:#3b82f6">WordPress</li><li style="--c:#8b5cf6">PHP</li><li style="--c:#ec4899">Elementor</li><li style="--c:#a855f7">WooCommerce</li></ul></div>
    <div class="float-card fc-code" data-depth="30"><span class="cc">// functions.php</span><br><span class="ck">add_action</span>(<span class="cs">'init'</span>, <span class="ck">function</span>() {{<br>&nbsp;&nbsp;<span class="cf">register_post_type</span>(<span class="cs">'project'</span>);<br>}});</div>
    <div class="float-card fc-perf" data-depth="18"><div class="perf-ring" style="--p:98"><b>98</b></div><div><b>Performance</b><br><span style="color:var(--muted)">Lighthouse score</span></div></div>
    <div class="float-card fc-term" id="terminal" data-depth="12"><div class="term-bar"><i></i><i></i><i></i></div><div class="term-body"><div class="term-out"></div></div></div>
    <span class="tech-chip" style="right:18%;top:-2%;animation-delay:-2s" data-depth="40">PHP 8.3</span>
    <span class="tech-chip" style="left:14%;top:-1%;animation-delay:-4s" data-depth="36">REST API</span>
  </div>
</div></section>

<div class="marquee" aria-hidden="true"><div class="marquee-track">{marquee}{marquee}</div></div>

<section class="section-tight" aria-label="Key numbers"><div class="wrap"><div class="stats-grid">
  <div class="stat glass reveal"><div class="stat-num" data-count="50" data-suffix="+">0</div><div class="stat-label">Projects delivered</div></div>
  <div class="stat glass reveal" style="--d:.08s"><div class="stat-num" data-count="3" data-suffix="+">0</div><div class="stat-label">Years of experience</div></div>
  <div class="stat glass reveal" style="--d:.16s"><div class="stat-num" data-count="10" data-suffix="+">0</div><div class="stat-label">Technologies</div></div>
  <div class="stat glass reveal" style="--d:.24s"><div class="stat-num" data-count="100" data-suffix="%">0</div><div class="stat-label">Responsive on every screen</div></div>
</div></div></section>

<section class="section" aria-labelledby="skills-title"><div class="wrap">
  <div class="section-head reveal"><span class="kicker">Technology stack</span><h2 id="skills-title">The tools I build with every day</h2><p class="lead">A focused toolkit for fast WordPress builds and reliable custom PHP, chosen for performance and long-term maintainability.</p></div>
  {tech_cards()}
</div></section>

<section class="section" aria-labelledby="services-title"><div class="wrap">
  <div class="section-head-row"><div class="section-head reveal"><span class="kicker">What I do</span><h2 id="services-title">Services that move your business forward</h2></div>
  <a class="btn btn-ghost reveal" href="services.html"><span>All services</span>{ic("arrow", "icon-arrow")}</a></div>
  <div class="grid-4">{svc_cards}</div>
</div></section>

<section class="section" aria-labelledby="work-title"><div class="wrap">
  <div class="section-head-row"><div class="section-head reveal"><span class="kicker">Selected work</span><h2 id="work-title">Featured projects</h2><p class="lead">A look at recent builds across WordPress, WooCommerce and custom PHP.</p></div>
  <a class="btn btn-primary reveal" href="projects.html"><span>View All Projects</span>{ic("arrow", "icon-arrow")}</a></div>
  <div class="projects-grid">{projs}</div>
</div></section>

{cta()}
'''
    page("index.html", "home", "Laxmon Mistry | WordPress & PHP Developer",
         "Laxmon Mistry is a freelance WordPress and PHP developer building fast, responsive, conversion-focused websites, custom themes, WooCommerce stores and PHP applications.", body)


# ------------------------------------------------------------------ ABOUT
def build_about():
    steps = "".join(f'<div class="step reveal" style="--d:{i*0.1:.1f}s"><div class="step-dot">0{i+1}</div><h3>{t}</h3><p>{d}</p></div>' for i, (t, d) in enumerate(PROCESS))
    skills = [("WordPress Development", 95), ("PHP Development", 90), ("HTML, CSS & Responsive Design", 95), ("Elementor & WooCommerce", 90),
              ("JavaScript", 82), ("API & AI Integration", 80), ("Website Performance Optimization", 86)]
    bars = "".join(f'<div class="skill-bar" style="--lvl:{v}%"><header><span>{n}</span><span>{v}%</span></header><div class="bar"><i></i></div></div>' for n, v in skills)
    journey = [
        ("2022", "Started with WordPress", "Began building business sites and learning how themes, plugins and the template hierarchy fit together."),
        ("2023", "Custom themes & WooCommerce", "Moved from page builders to hand-coded themes and built the first full online stores with custom checkout logic."),
        ("2024", "Deeper into PHP", "Started shipping custom PHP applications: dashboards, booking tools and secure REST integrations."),
        ("2025 – now", "Performance & AI integration", "Focused on Core Web Vitals, clean architecture and adding AI-powered features to client sites."),
    ]
    jhtml = "".join(f'<article class="journey-item glass reveal" style="--d:{i*0.08:.2f}s"><time>{y}</time><h3>{t}</h3><p>{d}</p></article>' for i, (y, t, d) in enumerate(journey))
    approach = [("target", "Business goals first", "Every decision starts with what the site needs to achieve: leads, sales or bookings. Design and code follow that."),
                ("code", "Clean, maintainable code", "Readable, documented and standards-based so any developer, including your future self, can build on it."),
                ("gauge", "Speed by default", "Lean markup, optimised media and minimal plugins keep pages quick without a last-minute rescue.")]
    ahtml = "".join(f'<article class="value-card glass reveal" style="--d:{i*0.1:.1f}s"><div class="svc-icon">{ic(ic_)}</div><h3>{t}</h3><p>{d}</p></article>' for i, (ic_, t, d) in enumerate(approach))
    why = [("users", "Direct communication", "You talk to the developer who writes your code. No account managers, no lost messages."),
           ("shield", "Secure by habit", "Input validation, sanitisation and updates are part of every build, not an upgrade."),
           ("bolt", "Fast turnaround", "Clear milestones and quick feedback loops keep projects moving without cutting corners."),
           ("layers", "Built to grow", "Modular structure means adding pages, products or features later is simple."),
           ("star", "Honest scoping", "Fixed, transparent quotes with no hidden extras once we agree on the plan."),
           ("check", "Support after launch", "Training, handover notes and follow-up fixes so the site keeps working for you.")]
    whtml = "".join(f'<article class="value-card glass reveal" style="--d:{(i%3)*0.1:.1f}s"><div class="svc-icon">{ic(ic_)}</div><h3>{t}</h3><p>{d}</p></article>' for i, (ic_, t, d) in enumerate(why))
    body = f'''
<section class="page-hero"><div class="wrap page-hero-split">
  <div>
    <nav class="crumbs hero-in" aria-label="Breadcrumb"><a href="index.html">Home</a><span>/</span><span aria-current="page">About</span></nav>
    <h1 class="hero-in">About Me</h1>
    <p class="lead hero-in" style="font-size:clamp(20px,2.4vw,28px);color:#c6d0f3;font-family:var(--font-display)">Turning ideas into powerful digital experiences.</p>
    <p class="lead hero-in" style="margin-top:22px">I am Laxmon Mistry, a WordPress and PHP developer focused on building modern, responsive and high-performance websites.</p>
    <div class="hero-actions hero-in"><a class="btn btn-primary" href="contact.html"><span>Let's Work Together</span>{ic("arrow", "icon-arrow")}</a><a class="btn btn-ghost" href="projects.html"><span>See my work</span></a></div>
  </div>
  <div class="about-photo hero-in">
    <div class="frame tilt" data-tilt="6"><div>{PHOTO.format(extra='decoding="async"')}</div></div>
    <div class="exp-badge glass"><b>3+</b><span>Years building for the web</span></div>
    <div class="float-card fc-a glass"><span class="fc-title">CURRENTLY</span><br><b>Freelance WordPress &amp; PHP</b></div>
  </div>
</div></section>

<section class="section"><div class="wrap intro-grid">
  <div class="reveal from-left"><span class="kicker">Introduction</span><h2 style="font-size:clamp(32px,4vw,54px);margin-top:18px">Developer first, with a designer's eye.</h2></div>
  <div class="reveal from-right">
    <p class="lead">I build websites that are quick to load, easy to manage and ready to grow. My work covers custom WordPress themes, Elementor and WooCommerce builds, and custom PHP applications.</p>
    <p class="lead">Clients come to me with a design file, a half-working site or just an idea. I turn each into a clean, reliable result by combining solid engineering with careful attention to layout, typography and user experience.</p>
    <p class="lead">I care about the details nobody notices until they are missing: sensible markup, accessible forms, secure code and pages that stay fast on a mid-range phone.</p>
  </div>
</div></section>

<section class="section" aria-labelledby="journey-title"><div class="wrap two-col">
  <div><div class="section-head reveal"><span class="kicker">My journey</span><h2 id="journey-title">From first theme to full applications</h2><p class="lead">Dates and milestones are a starting point. Update them with your own story.</p></div>
  <div class="journey">{jhtml}</div></div>
  <div><div class="section-head reveal"><span class="kicker">My skills</span><h2>Where I'm strongest</h2><p class="lead">Honest self-ratings from daily project work.</p></div>
  <div class="skill-bars glass" style="padding:34px">{bars}</div></div>
</div></section>

<section class="section" aria-labelledby="approach-title"><div class="wrap">
  <div class="section-head center reveal"><span class="kicker">My development approach</span><h2 id="approach-title">How I think about every build</h2></div>
  <div class="value-grid">{ahtml}</div>
</div></section>

<section class="section" aria-labelledby="process-title"><div class="wrap">
  <div class="section-head center reveal"><span class="kicker">Development process</span><h2 id="process-title">A clear path from idea to launch</h2><p class="lead">Six steps, each with a defined outcome, so you always know what happens next.</p></div>
  <div class="process" role="list"><div class="process-line" aria-hidden="true"></div>{steps}</div>
</div></section>

<section class="section" aria-labelledby="stack-title"><div class="wrap">
  <div class="section-head center reveal"><span class="kicker">Technology stack</span><h2 id="stack-title">My technology toolbox</h2></div>
  {tech_cards()}
</div></section>

<section class="section" aria-labelledby="why-title"><div class="wrap">
  <div class="section-head center reveal"><span class="kicker">Why work with me</span><h2 id="why-title">What you can expect</h2></div>
  <div class="value-grid">{whtml}</div>
</div></section>

{cta("Ready to start?", "Tell me about your project and get a clear plan within 24 hours.", "Let's Talk")}
'''
    page("about.html", "about", "About Laxmon Mistry | WordPress & PHP Developer",
         "Meet Laxmon Mistry, a WordPress and PHP developer. Learn about my journey, skills, development process and why clients trust me with their websites.", body)


# ------------------------------------------------------------------ SERVICES
def build_services():
    cards = []
    for i, (sid, icon, title, optval, desc, feats, techs, note) in enumerate(SERVICES):
        f = "".join(f'<li>{ic("check")}<span>{x}</span></li>' for x in feats)
        t = "".join(f"<li>{x}</li>" for x in techs)
        cards.append(f'''<article class="svc-detail glass reveal" id="{sid}" style="--d:{(i%2)*0.1:.1f}s">
  <div class="svc-head"><div class="svc-icon">{ic(icon)}</div><h3>{title}</h3><span class="svc-num">{i+1:02d}</span></div>
  <p>{desc}</p>
  <ul class="svc-features" aria-label="Features">{f}</ul>
  <ul class="tags" aria-label="Technologies">{t}</ul>
  <div class="svc-foot"><span style="color:var(--muted);font-size:14.5px">Typical start: within 1 week</span>
  <a class="btn btn-primary btn-sm" href="contact.html?service={optval.replace(" ", "%20").replace("&", "%26").replace("/", "%2F")}"><span>Get a quote</span>{ic("arrow", "icon-arrow")}</a></div>
</article>''')
    body = f'''
{hero_hd("Services", 'What I Can Build <span class="grad-text">For You</span>', "From a single landing page to a full custom PHP application, here is how I can help your business grow online.")}
<section class="section-tight"><div class="wrap"><div class="services-grid">{"".join(cards)}</div></div></section>
{cta("Not sure which service you need?", "Describe your goal and I will recommend the simplest path.", "Ask Me Anything")}
'''
    page("services.html", "services", "WordPress & PHP Development Services | Laxmon Mistry",
         "Hire a freelance WordPress and PHP developer: custom themes, Elementor, WooCommerce, Figma to WordPress, bug fixing, API and AI integration and speed optimisation.", body)


# ------------------------------------------------------------------ PROJECTS
def build_projects():
    filters = [("all", "All"), ("wordpress", "WordPress"), ("php", "PHP"), ("woocommerce", "WooCommerce"), ("elementor", "Elementor"), ("custom", "Custom Development")]
    fb = "".join(f'<button class="filter-btn{" is-active" if k == "all" else ""}" type="button" data-filter="{k}" aria-pressed="{"true" if k == "all" else "false"}">{n}<span class="count"></span></button>' for k, n in filters)
    cards = "".join(project_card(p, modal=True, delay=(i % 2) * 0.1) for i, p in enumerate(PROJECTS))
    body = f'''
{hero_hd("Projects", 'WordPress &amp; PHP <span class="grad-text">Projects</span>', "Sample work across desktop, laptop, tablet and mobile. Swap these placeholder mockups for your real screenshots at any time.")}
<section class="section-tight"><div class="wrap">
  <div class="filter-bar reveal" role="group" aria-label="Filter projects by category">{fb}</div>
  <div class="projects-grid" id="projects-grid">{cards}</div>
  <p class="empty-state">No projects in this category yet. New work is added regularly.</p>
</div></section>
{cta("Want results like these?", "Let's plan your website or application.", "Start a Project")}
<dialog class="modal" id="project-modal" aria-labelledby="modal-title"><button class="modal-close" type="button" aria-label="Close details">{ic("close")}<span class="sr-only">Close</span></button><div class="modal-body"></div></dialog>
<div hidden>{project_modal_templates()}</div>
'''
    page("projects.html", "projects", "WordPress & PHP Projects | Laxmon Mistry",
         "Browse WordPress, WooCommerce, Elementor and custom PHP projects by Laxmon Mistry, shown on desktop, laptop, tablet and mobile mockups.", body)


# ------------------------------------------------------------------ CONTACT
MAP_SVG = '''<svg viewBox="0 0 800 460" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Stylised map showing remote availability worldwide">
<defs>
<pattern id="mg" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M40 0H0V40" fill="none" stroke="#5f7bff" stroke-opacity=".12"/></pattern>
<radialGradient id="mglow" cx=".55" cy=".5" r=".6"><stop offset="0" stop-color="#6366f1" stop-opacity=".45"/><stop offset="1" stop-color="#6366f1" stop-opacity="0"/></radialGradient>
<linearGradient id="mroad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3b82f6"/><stop offset="1" stop-color="#22d3ee"/></linearGradient>
</defs>
<rect width="800" height="460" fill="#0a1124"/><rect width="800" height="460" fill="url(#mg)"/><rect width="800" height="460" fill="url(#mglow)"/>
<path d="M-20 330 C120 260 220 380 360 300 S600 180 820 250" fill="none" stroke="#1d3a78" stroke-width="30" opacity=".55"/>
<path d="M-20 330 C120 260 220 380 360 300 S600 180 820 250" fill="none" stroke="#2b5bd0" stroke-width="2" opacity=".6"/>
<g fill="#121c3d" stroke="#2a3a78" stroke-opacity=".6">
<rect x="60" y="60" width="120" height="70" rx="8"/><rect x="200" y="50" width="90" height="100" rx="8"/><rect x="320" y="70" width="140" height="60" rx="8"/>
<rect x="500" y="50" width="100" height="90" rx="8"/><rect x="630" y="70" width="130" height="70" rx="8"/><rect x="70" y="170" width="90" height="60" rx="8"/>
<rect x="520" y="360" width="110" height="60" rx="8"/><rect x="660" y="330" width="100" height="90" rx="8"/><rect x="90" y="380" width="140" height="50" rx="8"/><rect x="260" y="390" width="110" height="50" rx="8"/>
</g>
<g stroke="url(#mroad)" stroke-width="3" stroke-linecap="round" fill="none" opacity=".75">
<path d="M0 150 H800"/><path d="M300 0 V460"/><path d="M0 40 L800 440" stroke-opacity=".35" stroke-dasharray="6 10"/>
</g>
<g fill="#7da2ff" opacity=".7" font-family="ui-monospace,Menlo,monospace" font-size="12"><text x="80" y="155">/wp-content</text><text x="318" y="110">/includes</text><text x="540" y="190">api/v1</text></g>
<g transform="translate(430 205)"><circle class="map-pin" r="14" fill="#22d3ee" opacity=".5"/><circle r="9" fill="#22d3ee"/><circle r="4" fill="#06101f"/></g>
<g stroke="#8b5cf6" stroke-dasharray="3 6" fill="none" opacity=".8"><path d="M430 205 C520 120 640 120 700 90"/><path d="M430 205 C340 270 250 300 150 330"/></g>
<circle cx="700" cy="90" r="5" fill="#8b5cf6"/><circle cx="150" cy="330" r="5" fill="#8b5cf6"/>
</svg>'''


def build_contact():
    services = "".join(f'<option value="{esc(s)}">{esc(s)}</option>' for s in
                       ["WordPress Website Development", "Custom WordPress Theme Development", "PHP Web Development", "Elementor Website Development",
                        "WooCommerce Development", "Figma / PSD / XD to WordPress", "WordPress Bug Fixing", "API & AI Integration",
                        "Website Speed Optimization", "WordPress Customization", "Something else"])
    budgets = "".join(f'<option value="{esc(b)}">{esc(b)}</option>' for b in ["Under $300", "$300 – $1,000", "$1,000 – $3,000", "$3,000 – $7,000", "$7,000+", "Not sure yet"])
    info = [("mail", "Email", f'<a href="mailto:{EMAIL}">{EMAIL}</a>'), ("pin", "Location", "Remote · Worldwide"),
            ("clock", "Availability", "Mon – Sat, 10:00 – 19:00"), ("brief", "Freelance", "Open for new projects")]
    ihtml = "".join(f'<article class="info-card glass reveal" style="--d:{i*0.08:.2f}s"><div class="svc-icon">{ic(i_)}</div><h3>{t}</h3><p>{v}</p></article>' for i, (i_, t, v) in enumerate(info))
    faqs = [("How quickly will you reply?", "I reply to every enquiry within 24 hours, usually the same day. If your project is urgent, mention the deadline in your message."),
            ("Do you work with clients outside my country?", "Yes. I work remotely with clients worldwide and keep communication clear through email, chat or video calls."),
            ("How is pricing decided?", "After we talk, I send a fixed quote based on scope. For ongoing work I also offer hourly or monthly arrangements."),
            ("Can you fix or improve a site someone else built?", "Absolutely. I regularly take over existing WordPress sites to fix bugs, improve speed and add features without a rebuild.")]
    fhtml = "".join(f"<details><summary>{q}</summary><p>{a}</p></details>" for q, a in faqs)
    body = f'''
{hero_hd("Contact", 'Let\'s Build <span class="grad-text">Something Great</span>', "Have an idea, website project or custom development requirement? Let's discuss it.")}

<section class="section-tight"><div class="wrap"><div class="info-grid">{ihtml}</div></div></section>

<section class="section"><div class="wrap contact-grid">
  <div class="form-card glass reveal">
    <h2>Send me a message</h2>
    <p class="lead" style="font-size:16px">Share a few details and I will reply with next steps and a rough estimate.</p>
    <form id="contact-form" class="form-grid" novalidate method="post" data-endpoint="includes/contact-handler.php" data-token="includes/token.php" data-mailto="{EMAIL}">
      <div class="field"><input id="f-name" name="name" type="text" placeholder=" " autocomplete="name" required maxlength="80"><label for="f-name">Full name</label><p class="err" role="alert"></p></div>
      <div class="field"><input id="f-email" name="email" type="email" placeholder=" " autocomplete="email" required maxlength="120"><label for="f-email">Email address</label><p class="err" role="alert"></p></div>
      <div class="field"><input id="f-phone" name="phone" type="tel" placeholder=" " autocomplete="tel" maxlength="24"><label for="f-phone">Phone (optional)</label><p class="err" role="alert"></p></div>
      <div class="field select-wrap"><select id="f-service" name="service" required><option value="" disabled selected hidden></option>{services}</select><label for="f-service">Service needed</label><p class="err" role="alert"></p></div>
      <div class="field full select-wrap"><select id="f-budget" name="budget" required><option value="" disabled selected hidden></option>{budgets}</select><label for="f-budget">Estimated budget</label><p class="err" role="alert"></p></div>
      <div class="field full"><textarea id="f-message" name="message" placeholder=" " required minlength="20" maxlength="3000"></textarea><label for="f-message">Tell me about your project</label><p class="err" role="alert"></p></div>
      <div class="field"><input id="f-human" name="human" type="text" inputmode="numeric" placeholder=" " autocomplete="off" required maxlength="3"><label for="f-human" id="human-label">Human check</label><p class="err" role="alert"></p></div>
      <div class="hp" aria-hidden="true"><label for="f-website">Leave this field empty</label><input id="f-website" name="website" type="text" tabindex="-1" autocomplete="off"></div>
      <div class="alert success" role="status" aria-live="polite">{ic("check")}<span class="alert-text">Thank you! Your message has been sent successfully.</span></div>
      <div class="alert error" role="alert">{ic("bug")}<span class="alert-text">Something went wrong. Please try again.</span></div>
      <div class="form-footer"><p class="form-note">{ic("shield")}Your details stay private and are only used to reply.</p>
      <button class="btn btn-primary" type="submit"><span class="btn-label">Send Message</span>{ic("send")}</button></div>
    </form>
  </div>
  <aside class="side-stack">
    <div class="side-card glass reveal from-right"><h3>What happens next</h3>
      <ul class="check-list"><li>{ic("check")}<span>I read your message and reply within 24 hours.</span></li><li>{ic("check")}<span>We schedule a short call or continue by email.</span></li><li>{ic("check")}<span>You receive a clear scope, timeline and fixed quote.</span></li><li>{ic("check")}<span>Work starts once you approve the plan.</span></li></ul>
      <div class="avail"><span class="pulse-dot"></span>Currently accepting new freelance projects</div></div>
    <div class="side-card glass reveal from-right" style="--d:.1s"><h3>Prefer another channel?</h3><p style="color:var(--muted);margin-bottom:18px">Find me on these platforms or send an email directly.</p>
      <div class="socials">{"".join(f'<a href="{u}" target="_blank" rel="noopener noreferrer" aria-label="{n}">{ic(k)}</a>' for k, (n, u) in SOCIAL.items())}</div></div>
  </aside>
</div></section>

<section class="section-tight" aria-label="Location"><div class="wrap">
  <div class="map-card reveal scale-in">{MAP_SVG}
    <div class="map-label glass"><b>Remote-first, worldwide</b><span>Collaborating across time zones by email, chat and video.</span></div></div>
</div></section>

<section class="section" aria-labelledby="faq-title"><div class="wrap">
  <div class="section-head center reveal"><span class="kicker">Before you write</span><h2 id="faq-title">Common questions</h2></div>
  <div class="faq reveal">{fhtml}</div>
</div></section>
'''
    page("contact.html", "contact", "Contact Laxmon Mistry | WordPress & PHP Developer",
         "Contact Laxmon Mistry for WordPress, WooCommerce, Elementor and custom PHP development. Send a message and get a reply within 24 hours.", body)


if __name__ == "__main__":
    build_home(); build_about(); build_services(); build_projects(); build_contact()
    print("pages built")
