<?php
/**
 * Issues a CSRF token + a tiny human-check question for the contact form.
 * Called with fetch() by js/main.js when the contact page loads.
 */
declare(strict_types=1);
require __DIR__ . '/config.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') {
    json_response(['success' => false, 'message' => 'Method not allowed.'], 405);
}

start_secure_session();

$a = random_int(2, 9);
$b = random_int(1, 9);

$_SESSION['csrf_token']   = bin2hex(random_bytes(32));
$_SESSION['human_answer'] = $a + $b;
$_SESSION['form_issued']  = time();

json_response([
    'success'  => true,
    'token'    => $_SESSION['csrf_token'],
    'question' => "$a + $b = ?",
]);
