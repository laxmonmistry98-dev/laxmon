<?php
/**
 * Site configuration — edit these values before deploying.
 * Keep this file outside the public web root if your host allows it.
 */
declare(strict_types=1);

// Where contact-form messages are delivered.
const CONTACT_RECIPIENT = 'contact@laxmonmistry.com';   // TODO: replace with your real email
const CONTACT_FROM      = 'no-reply@laxmonmistry.com';  // Use an address on YOUR domain (improves deliverability / SPF)
const SITE_NAME         = 'Laxmon Mistry Portfolio';

// Form protection
const MIN_FILL_SECONDS  = 3;     // Bots submit instantly; humans do not.
const MAX_PER_HOUR      = 5;     // Per-session submission limit.
const MIN_GAP_SECONDS   = 30;    // Cooldown between submissions.
const LOG_MESSAGES      = true;  // Also store messages in /storage/messages.log (blocked from web by .htaccess)

// Allowed select values (server-side allow-list)
const SERVICES = [
    'WordPress Website Development', 'Custom WordPress Theme Development', 'PHP Web Development',
    'Elementor Website Development', 'WooCommerce Development', 'Figma / PSD / XD to WordPress',
    'WordPress Bug Fixing', 'API & AI Integration', 'Website Speed Optimization',
    'WordPress Customization', 'Something else',
];
const BUDGETS = ['Under $300', '$300 – $1,000', '$1,000 – $3,000', '$3,000 – $7,000', '$7,000+', 'Not sure yet'];

function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('lm_contact');
    session_start();
}

function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
