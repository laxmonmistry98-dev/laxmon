<?php
/**
 * Secure contact form handler.
 * Protections: POST-only, CSRF token, honeypot, time-trap, human check,
 * allow-listed selects, strict validation, sanitization, header-injection
 * prevention, per-session rate limiting.
 */
declare(strict_types=1);
require __DIR__ . '/config.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_response(['success' => false, 'message' => 'Method not allowed.'], 405);
}

start_secure_session();

/* ---- Helpers ---- */
function clean_line(string $v, int $max): string
{
    $v = trim(strip_tags($v));
    $v = preg_replace('/[\r\n\t]+/', ' ', $v) ?? '';       // kills header-injection attempts
    $v = preg_replace('/\s{2,}/', ' ', $v) ?? '';
    return mb_substr($v, 0, $max);
}
function clean_text(string $v, int $max): string
{
    $v = trim(strip_tags($v));
    $v = str_replace(["\r\n", "\r"], "\n", $v);
    $v = preg_replace("/\n{3,}/", "\n\n", $v) ?? '';
    return mb_substr($v, 0, $max);
}

/* ---- 1. CSRF ---- */
$sent = (string)($_POST['csrf_token'] ?? '');
$real = (string)($_SESSION['csrf_token'] ?? '');
if ($real === '' || !hash_equals($real, $sent)) {
    json_response(['success' => false, 'message' => 'Your session expired. Please refresh the page and try again.'], 403);
}

/* ---- 2. Honeypot (hidden "website" field must stay empty) ---- */
if (trim((string)($_POST['website'] ?? '')) !== '') {
    json_response(['success' => true, 'message' => 'Thank you! Your message has been sent successfully.']); // bots learn nothing
}

/* ---- 3. Time-trap ---- */
$issued = (int)($_SESSION['form_issued'] ?? 0);
if ($issued === 0 || (time() - $issued) < MIN_FILL_SECONDS) {
    json_response(['success' => false, 'message' => 'That was a little too fast. Please wait a moment and send again.'], 429);
}

/* ---- 4. Rate limit ---- */
$now  = time();
$hits = array_filter($_SESSION['hits'] ?? [], static fn($t) => ($now - (int)$t) < 3600);
if (count($hits) >= MAX_PER_HOUR || ($hits && ($now - max($hits)) < MIN_GAP_SECONDS)) {
    json_response(['success' => false, 'message' => 'Too many messages in a short time. Please try again later.'], 429);
}

/* ---- 5. Validate ---- */
$name    = clean_line((string)($_POST['name'] ?? ''), 80);
$email   = trim((string)($_POST['email'] ?? ''));
$phone   = clean_line((string)($_POST['phone'] ?? ''), 24);
$service = clean_line((string)($_POST['service'] ?? ''), 80);
$budget  = clean_line((string)($_POST['budget'] ?? ''), 40);
$message = clean_text((string)($_POST['message'] ?? ''), 3000);
$human   = (int)($_POST['human'] ?? -1);

$errors = [];
if (mb_strlen($name) < 2) {
    $errors['name'] = 'Please enter your full name.';
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 120 || preg_match('/[\r\n]/', $email)) {
    $errors['email'] = 'Enter a valid email address.';
}
if ($phone !== '' && !preg_match('/^[+()\d\s.\-]{7,24}$/', $phone)) {
    $errors['phone'] = 'Enter a valid phone number.';
}
if (!in_array($service, SERVICES, true)) {
    $errors['service'] = 'Choose a service from the list.';
}
if (!in_array($budget, BUDGETS, true)) {
    $errors['budget'] = 'Choose a budget range.';
}
if (mb_strlen($message) < 20) {
    $errors['message'] = 'Please write at least 20 characters.';
}
if ($human !== (int)($_SESSION['human_answer'] ?? -999)) {
    $errors['human'] = 'The human check answer is not right.';
}
if ($errors) {
    json_response(['success' => false, 'errors' => $errors], 422);
}

/* ---- 6. Send the email ---- */
$subject = 'New project enquiry from ' . $name . ' — ' . $service;
$body  = "You received a new message from your portfolio website.\n\n";
$body .= "Name:    $name\nEmail:   $email\nPhone:   " . ($phone ?: '—') . "\nService: $service\nBudget:  $budget\n\n";
$body .= "Message:\n$message\n\n---\nIP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . "\nSent: " . date('c') . "\n";

$headers = [
    'From'         => SITE_NAME . ' <' . CONTACT_FROM . '>',
    'Reply-To'     => $email,   // validated above: no CR/LF possible
    'MIME-Version' => '1.0',
    'Content-Type' => 'text/plain; charset=UTF-8',
    'X-Mailer'     => 'PHP/' . PHP_VERSION,
];
$encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
$sentOk = @mail(CONTACT_RECIPIENT, $encodedSubject, $body, $headers);

if (LOG_MESSAGES) {
    $dir = dirname(__DIR__) . '/storage';
    if (is_dir($dir) && is_writable($dir)) {
        $row = json_encode(compact('name', 'email', 'phone', 'service', 'budget', 'message'), JSON_UNESCAPED_UNICODE);
        @file_put_contents($dir . '/messages.log', '[' . date('c') . '] ' . $row . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}

if (!$sentOk && !LOG_MESSAGES) {
    json_response(['success' => false, 'message' => 'The mail server did not accept the message. Please email me directly.'], 500);
}

/* ---- 7. Success: burn the token, record the rate-limit hit ---- */
$hits[] = $now;
$_SESSION['hits'] = array_values($hits);
unset($_SESSION['csrf_token'], $_SESSION['human_answer']);
$_SESSION['form_issued'] = 0;

json_response(['success' => true, 'message' => 'Thank you! Your message has been sent successfully.']);
